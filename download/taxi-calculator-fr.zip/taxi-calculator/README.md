# Calculateur de Tarif Taxi – Taxi Chomedey / besttaxilaval.ca

Standalone HTML calculator with CTQ day/night rates, fixed price, and Uber/Lyft comparison.

## Pricing rules (current)

**Prix fixe**

\[
\text{prix fixe} = \max(\text{UberX pointe},\ \text{compteur CTQ jour/nuit})
\]

**Comptant** = prix fixe ÷ 1.034 (removes 3.4% terminal fee)

**CTQ meter**
| | Jour (5h–23h) | Nuit (23h–5h) |
|---|---|---|
| Start | $4.10 + $1.05 levy = **$5.15** | $4.70 + $1.05 levy = **$5.75** |
| Per km | $2.05 | $2.35 |
| Per min | $0.77 | $0.89 |

Below ~22.5 km/h the meter charges **time only**; above it, **distance only** — never both on the same stretch.

**UberX estimate** (drives the “pointe” side of prix fixe)

\[
\text{habituel} = 5.75 + 1.15 \times \text{km} + 0.28 \times \text{min}
\]
\[
\text{pointe} = \text{habituel} \times 1.45
\]

Same prix fixe at all hours (pointe et hors-pointe).

## Files

| File | Role |
|------|------|
| `index.html` | Full frontend (open in a browser) |
| `worker.js` | Optional Cloudflare Worker backend |
| `README.md` | This file |

## Demo mode (no API keys)

1. Open `index.html` in a browser.
2. Leave `demoMode: true` in `CONFIG`.
3. Type addresses (e.g. Laval → YUL) and calculate.

Known demo pairs: Laval ↔ YUL, centre-ville ↔ YUL, Montréal ↔ YUL.

## Production (optional)

1. Add a Google Maps browser key (Places + Maps JavaScript).
2. Deploy `worker.js` on Cloudflare with `GOOGLE_MAPS_API_KEY`.
3. Set `workerUrl` and `demoMode: false` in `CONFIG`.

## Example — 27 km · ~32 min

| | Compteur CTQ | UberX pointe | Prix fixe | Comptant |
|---|---|---|---|---|
| Jour | ~$60.50 | ~$67 | **$67** | **$64.80** |
| Nuit | ~$69.20 | ~$67 | **$70** | **$67.70** |
