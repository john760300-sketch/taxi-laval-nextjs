/**
 * Cloudflare Worker – Taxi Fare Calculator Backend
 * -------------------------------------------------
 * Protects your Google Maps API key and calculates CTQ fares.
 *
 * Setup:
 * 1. Create a Worker in Cloudflare Dashboard → Workers & Pages → Create
 * 2. Paste this code
 * 3. Add environment variables (Secrets):
 *      GOOGLE_MAPS_API_KEY = your Google Maps key (Distance Matrix + Directions enabled)
 * 4. Deploy → copy the Worker URL into index.html (CONFIG.workerUrl)
 * 5. Set demoMode: false in the frontend
 */

const RATES = {
  day: {
    base: 4.10,
    perKm: 2.05,
    perMin: 0.77,
    label: "Jour (5h–23h)"
  },
  night: {
    base: 4.70,
    perKm: 2.35,
    perMin: 0.89,
    label: "Nuit (23h–5h)"
  },
  levy: 1.05
};

const TERMINAL_FEE_RATE = 0.034; // 3.4 %
const HEURES_POINTE = [
  { start: 7, end: 9 },
  { start: 16, end: 19 }
];

export default {
  async fetch(request, env) {
    // CORS
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: corsHeaders()
      });
    }

    if (request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    try {
      const body = await request.json();
      const { origin, destination, datetime } = body;

      if (!origin || !destination) {
        return json({ error: "origin and destination are required" }, 400);
      }

      // 1. Call Google Maps Directions API (prefer shortest distance)
      const directions = await getDirections(origin, destination, env.GOOGLE_MAPS_API_KEY);

      if (!directions) {
        return json({ error: "Could not calculate route. Check addresses." }, 400);
      }

      const distanceKm = directions.distanceMeters / 1000;
      const durationMin = directions.durationSeconds / 60;

      // 2. Calculate CTQ fare
      const result = calculateFare(distanceKm, durationMin, datetime);

      return json(result);
    } catch (err) {
      console.error(err);
      return json({ error: "Internal error" }, 500);
    }
  }
};

async function getDirections(origin, destination, apiKey) {
  // Prefer the route with shortest distance (not always the fastest)
  const url = new URL("https://maps.googleapis.com/maps/api/directions/json");
  url.searchParams.set("origin", origin);
  url.searchParams.set("destination", destination);
  url.searchParams.set("mode", "driving");
  url.searchParams.set("alternatives", "true"); // get multiple routes
  url.searchParams.set("language", "fr");
  url.searchParams.set("region", "ca");
  url.searchParams.set("key", apiKey);

  const res = await fetch(url.toString());
  const data = await res.json();

  if (data.status !== "OK" || !data.routes?.length) {
    console.error("Directions API error:", data.status, data.error_message);
    return null;
  }

  // Choose the route with the shortest distance
  let best = data.routes[0];
  for (const route of data.routes) {
    const dist = route.legs[0].distance.value;
    if (dist < best.legs[0].distance.value) {
      best = route;
    }
  }

  const leg = best.legs[0];
  return {
    distanceMeters: leg.distance.value,
    durationSeconds: leg.duration.value, // or duration_in_traffic if available
    summary: best.summary
  };
}

function calculateFare(distanceKm, durationMin, datetimeStr) {
  const isNight = isNightTime(datetimeStr);
  const pointe = estHeurePointe(datetimeStr);
  const rate = isNight ? RATES.night : RATES.day;

  const meterDay = ctqMeter(distanceKm, durationMin, RATES.day);
  const meterNight = ctqMeter(distanceKm, durationMin, RATES.night);
  const meter = isNight ? meterNight : meterDay;

  const uber = rideshare(distanceKm, durationMin, 5.75, 1.15, 0.28, 8, 1.45);
  const lyft = rideshare(distanceKm, durationMin, 5.05, 1.05, 0.25, 7, 1.4);

  // Prix fixe = max(UberX pointe, compteur CTQ jour/nuit selon l'heure)
  const cardPrice = Math.max(uber.high, Math.ceil(meter));
  const cashPrice = Math.round((cardPrice / (1 + TERMINAL_FEE_RATE)) * 100) / 100;
  const terminalFee = Math.round((cardPrice - cashPrice) * 100) / 100;
  const baseFare = cashPrice;

  return {
    distanceKm: Number(distanceKm.toFixed(1)),
    durationMin: Math.round(durationMin),
    rateType: rate.label,
    baseFare,
    terminalFee,
    lockedPrice: cardPrice,
    creditPrice: cardPrice,
    cashPrice,
    estPointe: pointe,
    isNight,
    taxiDay: Math.round(meterDay * 100) / 100,
    taxiNight: Math.round(meterNight * 100) / 100,
    uberEstimate: `$${uber.low} – $${uber.high}`,
    lyftEstimate: `$${lyft.low} – $${lyft.high}`,
    meterEstimate: Math.round(meter)
  };
}

function ctqMeter(distanceKm, durationMin, rate) {
  const changeoverKmh = (rate.perMin * 60) / rate.perKm;
  const avgKmh = durationMin > 0 ? (distanceKm / durationMin) * 60 : 999;
  const distanceCost = distanceKm * rate.perKm;
  const timeCost = durationMin * rate.perMin;
  const useTime = avgKmh < changeoverKmh && timeCost > distanceCost;
  return rate.base + (useTime ? timeCost : distanceCost) + RATES.levy;
}

function rideshare(distanceKm, durationMin, flag, perKm, perMin, minimum, surge) {
  const typical = Math.max(minimum, flag + distanceKm * perKm + durationMin * perMin);
  return {
    low: Math.round(typical),
    high: Math.round(typical * surge)
  };
}

function isNightTime(datetimeStr) {
  const date = datetimeStr ? new Date(datetimeStr) : new Date();
  const hour = date.getHours();
  return hour >= 23 || hour < 5;
}

function estHeurePointe(datetimeStr) {
  const date = datetimeStr ? new Date(datetimeStr) : new Date();
  if (Number.isNaN(date.getTime())) return false;
  const day = date.getDay();
  if (day === 0 || day === 6) return false;
  const hour = date.getHours();
  return HEURES_POINTE.some((slot) => hour >= slot.start && hour < slot.end);
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...corsHeaders()
    }
  });
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}
